import java.util.Properties

import edu.stanford.nlp.ling.CoreAnnotations
import edu.stanford.nlp.neural.rnn.RNNCoreAnnotations
import edu.stanford.nlp.pipeline.Annotation
import edu.stanford.nlp.pipeline.StanfordCoreNLP
import edu.stanford.nlp.sentiment.SentimentCoreAnnotations
import edu.stanford.nlp.trees.Tree
import edu.stanford.nlp.util.CoreMap
import scala.util.control._
import scala.collection.JavaConversions._
import util.control.Breaks._
import edu.stanford.nlp.ling._
import scala.collection.mutable._

object sentimentanalysis extends App{

  val line = "Account they will still have cover for unlimited GP consultations (codes) at a network GP paid from the Insured Network Benefit Insured Network Benefit Was it explained that once a member uses up their Medical Savings Account they also have unlimited in and out-of-hospital pathology as long as the doctor (network or non-network GP) uses a provider in our network Insured Network Benefit Was it explained that once a member uses up their Medical Savings Account they also have unlimited cover to day-to-day generic medicine for schedule and above medicines within our network of pharmacies.";
  val props = new Properties();
  props.setProperty("annotators", "tokenize, ssplit, parse, sentiment");
  val nlp = new StanfordCoreNLP(props);
  println(getSentimentForLabel(line, "Jam"));

  // get sentiment for label and entire string
  def getSentimentForLabel(line: String, aspect: String): (ListBuffer[Int], ListBuffer[Double] ,ListBuffer[Int], ListBuffer[Double]) = {

    val lstMainSentiment = scala.collection.mutable.ListBuffer.empty[Int]
    val lstMainScore = scala.collection.mutable.ListBuffer.empty[Double]
    val lstAspectSentiment = scala.collection.mutable.ListBuffer.empty[Int]
    val lstAspectScore = scala.collection.mutable.ListBuffer.empty[Double]

    if (line != null && line.length > 0) {
      val annotation = nlp.process(line)

      //breakable {
        // loop through every sentence
        for (sentence <- annotation.get(classOf[CoreAnnotations.SentencesAnnotation])) {

          // get root tree, its sentiment and score
          val tree = sentence.get(classOf[SentimentCoreAnnotations.SentimentAnnotatedTree])
          var mainSentiment = RNNCoreAnnotations.getPredictedClass(tree);
          lstMainSentiment += mainSentiment;
          lstMainScore  += tree.label().asInstanceOf[edu.stanford.nlp.ling.CoreLabel].get(classOf[RNNCoreAnnotations.Predictions]).get(mainSentiment);

          // set variables
          var aspectScore = -1.0; // negative if aspect not found
          var aspectIndex = 0 // starting index to find aspect
          var minSentiment = 2  // neutral

          // get all leaf nodes
          val leaves = tree.getLeaves()
          println(leaves)

          breakable {

            // loop through leaf nodes
            for (leave <- leaves.toArray) {

              // check if leaf node matches aspect
              if (leave.toString().equalsIgnoreCase(aspect)) {

                // get tree of aspect
                var aspectTree: edu.stanford.nlp.trees.LabeledScoredTreeNode = tree.getLeaves()(aspectIndex)

                // loop through every parent of aspect until we find a non-neutral node
                while (!aspectTree.label().toString().equalsIgnoreCase("ROOT") && minSentiment == 2) {

                  // reset aspect score
                  aspectScore = 0.2

                  // get parent
                  aspectTree = aspectTree.parent(tree).asInstanceOf[edu.stanford.nlp.trees.LabeledScoredTreeNode];

                  // get matrix of scores
                  val leafNodeSentimentMatrix = aspectTree.label().asInstanceOf[edu.stanford.nlp.ling.CoreLabel].get(classOf[RNNCoreAnnotations.Predictions])

                  // set aspect score and index to the max value in matrix
                  for (index <- 0 until 5) {
                    if (aspectScore < leafNodeSentimentMatrix.get(index)) {
                      aspectScore = leafNodeSentimentMatrix.get(index)
                      minSentiment = index
                    }
                  }
                }

                // break from inner loop if aspect is found
                break;
              }
              // move to next leaf node
              aspectIndex = aspectIndex + 1
            }
          }

          // set final aspect sentiment
          lstAspectSentiment += minSentiment
          lstAspectScore += aspectScore
        }
    }

    // return values
    (lstMainSentiment, lstMainScore, lstAspectSentiment, lstAspectScore);
  }

  def getSentimentString(sentiment: Double): String = {

    math.round(sentiment) match
    {
      case 0.0 => "Very Negative"
      case 1.0 => "Negative"
      case 2.0 => "Neutral"
      case 3.0 => "Positive"
      case 4.0 => "Very Positive"
    }
  }

  println(getSentimentString(2.6))

}
